package com.example.demo;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Employee {

	
	ArrayList<Employeee> e =new ArrayList<Employeee>();
	
	public Employee() {
		e.add(new Employeee("qwe","wsc",1));
		e.add(new Employeee("qwe","wsc",2));
		e.add(new Employeee("qwe","wsc",3));
		
		
	}
	@GetMapping("Allrecord")
	public ArrayList<Employeee> display() {
		return e;
	}
	
	@PostMapping("/insert")
	public ArrayList<Employeee> AllEmp(@RequestBody Employeee empl) {
		e.add(empl);
		return e;
		
	}
	
	@PutMapping("update")
	public  ArrayList<Employeee> updateemp(@RequestBody Employeee empl) {
		e.add(empl);
		return e;
	}
}
