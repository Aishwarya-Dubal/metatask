package com.example.demo;

public class Employeee {

	String fname;
	String lname;
	int id;
	public Employeee() {
		super();
	}
	public Employeee(String fname, String lname, int id) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Employeee [fname=" + fname + ", lname=" + lname + ", id=" + id + "]";
	}
	
}
