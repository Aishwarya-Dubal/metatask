package meta;

import java.util.Scanner;

public class Noclass {

	int a,b;
	Scanner scan =new Scanner(System.in);
    System.out.println("Enter no :")
    a=scan.nextint();
    System.out.println("Enter no :");
    b=scan.nextInt();

}
