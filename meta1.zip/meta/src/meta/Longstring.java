package meta;

public class Longstring {
public static void main(String[] args) {
	
	String str="helloo world hii";
	String[] t=str.split(" ");
	String longstring=" ";
	for(int i=0;i<t.length;i++) {
		for(int j=1;j<t.length;j++) {
			if(t[i].length()>= t[j].length()) {
				longstring=t[i];
			}
		}
		
	}
	System.out.println(longstring);
}

}
